import { useState } from "react";
import { Link } from "wouter";

type LeadStatus = "New" | "Called" | "Not Interested" | "Converted";

interface Lead {
  id: number;
  name: string;
  category: string;
  address: string;
  phone: string;
  rating: string;
  status: LeadStatus;
}

const MOCK_LEADS: Lead[] = [
  { id: 1, name: "Sunset Auto Repair", category: "Auto Repair", address: "1204 Sunset Blvd, Los Angeles, CA", phone: "(323) 555-0142", rating: "4.2 ★", status: "New" },
  { id: 2, name: "Burbank Plumbing Co", category: "Plumbing", address: "88 Victory Blvd, Burbank, CA", phone: "(818) 555-0289", rating: "4.6 ★", status: "New" },
  { id: 3, name: "Valley Dental Group", category: "Dentist", address: "5500 Lankershim Blvd, N. Hollywood", phone: "(818) 555-0031", rating: "3.9 ★", status: "Called" },
  { id: 4, name: "Echo Park Diner", category: "Restaurant", address: "222 Glendale Blvd, Los Angeles, CA", phone: "(213) 555-0371", rating: "4.1 ★", status: "New" },
  { id: 5, name: "ProClean Services", category: "Cleaning", address: "900 N Cahuenga, Hollywood, CA", phone: "(323) 555-0590", rating: "4.8 ★", status: "Converted" },
];

type DevTab = "crm";

export default function DevAdmin() {
  const [tab] = useState<DevTab>("crm");
  const [zipCode, setZipCode] = useState("");
  const [searching, setSearching] = useState(false);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!zipCode.trim()) return;
    setSearching(true);
    setHasSearched(false);
    setTimeout(() => {
      setLeads(MOCK_LEADS.map((l) => ({ ...l, status: "New" as LeadStatus })));
      setSearching(false);
      setHasSearched(true);
    }, 1800);
  }

  function updateStatus(id: number, status: LeadStatus) {
    setLeads((prev) => prev.map((l) => l.id === id ? { ...l, status } : l));
  }

  function handleSaveToDrive() {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }, 1500);
  }

  const statusOptions: LeadStatus[] = ["New", "Called", "Not Interested", "Converted"];

  const statusColors: Record<LeadStatus, string> = {
    New: "text-zinc-300 bg-zinc-800 border-zinc-700",
    Called: "text-zinc-400 bg-zinc-900 border-zinc-700",
    "Not Interested": "text-zinc-600 bg-zinc-900 border-zinc-800",
    Converted: "text-zinc-200 bg-zinc-700 border-zinc-600",
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Header */}
      <header className="border-b border-zinc-800 px-6 h-14 flex items-center justify-between shrink-0">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="w-5 h-5 bg-white rounded-sm flex items-center justify-center">
              <span className="text-black text-[10px] font-black">F</span>
            </div>
            <span className="text-white font-semibold tracking-tight text-sm">FUGTH MANAGEMENT</span>
          </div>
        </Link>
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded border border-zinc-700 bg-zinc-900 text-zinc-400 text-[10px] uppercase tracking-widest font-medium">
            <span className="w-1 h-1 rounded-full bg-zinc-400" />
            Dev Admin
          </span>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-52 border-r border-zinc-800 bg-zinc-950 flex flex-col py-4 px-2 shrink-0">
          <p className="text-zinc-700 text-[10px] uppercase tracking-widest px-3 mb-3">Admin Tools</p>
          <button
            className="w-full text-left px-3 py-2.5 rounded text-sm font-medium transition-colors mb-1 bg-white text-black"
          >
            Lead CRM
          </button>
          <button className="w-full text-left px-3 py-2.5 rounded text-sm text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors mb-1 opacity-50 cursor-not-allowed">
            Analytics
          </button>
          <button className="w-full text-left px-3 py-2.5 rounded text-sm text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors mb-1 opacity-50 cursor-not-allowed">
            System Logs
          </button>
          <button className="w-full text-left px-3 py-2.5 rounded text-sm text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors mb-1 opacity-50 cursor-not-allowed">
            Feature Flags
          </button>

          <div className="flex-1" />
          <div className="border-t border-zinc-800 pt-4 px-3">
            <Link href="/">
              <button className="w-full text-left text-zinc-500 text-xs hover:text-white transition-colors py-1.5">← Back to Site</button>
            </Link>
          </div>
        </aside>

        {/* Main */}
        {tab === "crm" && (
          <main className="flex-1 overflow-y-auto p-8">
            <div className="mb-8">
              <h1 className="text-xl font-bold tracking-tight mb-1">Lead CRM</h1>
              <p className="text-zinc-500 text-sm">Search for local businesses by zip code and manage your outreach pipeline.</p>
            </div>

            {/* Search */}
            <div className="bg-zinc-900 border border-zinc-800 rounded p-6 mb-6">
              <p className="text-zinc-400 text-xs uppercase tracking-wider mb-4">Find Leads</p>
              <form onSubmit={handleSearch} className="flex gap-3">
                <div className="space-y-1 flex-1 max-w-xs">
                  <label className="text-zinc-500 text-xs">Zip Code</label>
                  <input
                    type="text"
                    value={zipCode}
                    onChange={(e) => setZipCode(e.target.value)}
                    placeholder="e.g. 90210"
                    maxLength={10}
                    className="w-full bg-zinc-950 border border-zinc-800 text-white text-sm rounded px-3 py-2.5 placeholder-zinc-700 focus:outline-none focus:border-zinc-600 transition-colors font-mono"
                  />
                </div>
                <div className="flex items-end">
                  <button
                    type="submit"
                    disabled={!zipCode.trim() || searching}
                    className="px-5 py-2.5 bg-white text-black text-sm font-semibold rounded hover:bg-zinc-200 transition-colors disabled:opacity-40 flex items-center gap-2"
                  >
                    {searching ? (
                      <>
                        <span className="w-3 h-3 border border-black border-t-transparent rounded-full animate-spin" />
                        Searching...
                      </>
                    ) : (
                      "Search Google Maps"
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* Results */}
            {hasSearched && leads.length > 0 && (
              <div className="bg-zinc-900 border border-zinc-800 rounded overflow-hidden">
                <div className="border-b border-zinc-800 px-4 py-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <p className="text-zinc-400 text-xs uppercase tracking-wider">Results</p>
                    <span className="px-2 py-0.5 bg-zinc-800 border border-zinc-700 text-zinc-400 text-xs rounded font-mono">
                      {leads.length} businesses
                    </span>
                  </div>
                  <button
                    onClick={handleSaveToDrive}
                    disabled={saving}
                    className="flex items-center gap-2 px-4 py-1.5 bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs font-medium rounded hover:bg-zinc-700 hover:text-white transition-colors disabled:opacity-50"
                  >
                    {saving ? (
                      <>
                        <span className="w-3 h-3 border border-zinc-400 border-t-transparent rounded-full animate-spin" />
                        Saving...
                      </>
                    ) : saved ? (
                      "Saved to Drive ✓"
                    ) : (
                      "Save to Google Drive"
                    )}
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-zinc-800">
                        <th className="text-left px-4 py-3 text-zinc-600 text-xs font-medium uppercase tracking-wider">Business</th>
                        <th className="text-left px-4 py-3 text-zinc-600 text-xs font-medium uppercase tracking-wider">Category</th>
                        <th className="text-left px-4 py-3 text-zinc-600 text-xs font-medium uppercase tracking-wider">Phone</th>
                        <th className="text-left px-4 py-3 text-zinc-600 text-xs font-medium uppercase tracking-wider">Rating</th>
                        <th className="text-left px-4 py-3 text-zinc-600 text-xs font-medium uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {leads.map((lead, i) => (
                        <tr key={lead.id} className={`hover:bg-zinc-800/30 transition-colors ${i < leads.length - 1 ? "border-b border-zinc-800/50" : ""}`}>
                          <td className="px-4 py-3">
                            <p className="text-white font-medium text-sm">{lead.name}</p>
                            <p className="text-zinc-600 text-xs mt-0.5">{lead.address}</p>
                          </td>
                          <td className="px-4 py-3 text-zinc-400 text-sm">{lead.category}</td>
                          <td className="px-4 py-3 text-zinc-400 text-sm font-mono">{lead.phone}</td>
                          <td className="px-4 py-3 text-zinc-400 text-sm">{lead.rating}</td>
                          <td className="px-4 py-3">
                            <select
                              value={lead.status}
                              onChange={(e) => updateStatus(lead.id, e.target.value as LeadStatus)}
                              className={`px-2 py-1 rounded border text-xs font-medium bg-transparent cursor-pointer focus:outline-none transition-colors ${statusColors[lead.status]}`}
                            >
                              {statusOptions.map((s) => (
                                <option key={s} value={s} className="bg-zinc-900 text-zinc-300">{s}</option>
                              ))}
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {hasSearched && leads.length === 0 && (
              <div className="border border-zinc-800 rounded p-12 text-center">
                <p className="text-zinc-500 text-sm">No results found for zip code {zipCode}.</p>
              </div>
            )}

            {!hasSearched && !searching && (
              <div className="border border-dashed border-zinc-800 rounded p-12 text-center">
                <p className="text-zinc-600 text-sm">Enter a zip code above and click "Search Google Maps" to pull local business leads.</p>
              </div>
            )}
          </main>
        )}
      </div>
    </div>
  );
}
