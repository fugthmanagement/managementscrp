import { useState } from "react";
import { Link } from "wouter";

type Tab = "inbox" | "consultant" | "knowledge";

const MOCK_CALLS = [
  { id: 1, caller: "(323) 555-0142", time: "Today, 2:14 PM", status: "Missed", notes: "No voicemail" },
  { id: 2, caller: "(818) 555-0289", time: "Today, 11:03 AM", status: "Missed", notes: "Called twice" },
  { id: 3, caller: "(213) 555-0371", time: "Yesterday, 4:47 PM", status: "Missed", notes: "" },
  { id: 4, caller: "(747) 555-0093", time: "Yesterday, 9:22 AM", status: "Recovered", notes: "AI follow-up sent" },
  { id: 5, caller: "(310) 555-0558", time: "Mon, 3:05 PM", status: "Missed", notes: "" },
];

const MOCK_CHAT = [
  { role: "assistant", text: "Hey! I'm your AI Consultant — trained on your business data. What would you like to know today?" },
];

export default function Dashboard() {
  const [tab, setTab] = useState<Tab>("inbox");
  const [messages, setMessages] = useState(MOCK_CHAT);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [kbFields, setKbFields] = useState({ businessName: "", industry: "", services: "", hours: "", location: "", notes: "" });
  const [kbSaved, setKbSaved] = useState(false);

  function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;
    setMessages((m) => [...m, { role: "user", text: input }]);
    setInput("");
    setSending(true);
    setTimeout(() => {
      setMessages((m) => [...m, { role: "assistant", text: "Great question. Once your knowledge base is set up, I'll be able to give you specific answers about your pricing, customer patterns, and operations. Want to fill that in now?" }]);
      setSending(false);
    }, 1200);
  }

  function saveKb(e: React.FormEvent) {
    e.preventDefault();
    setKbSaved(true);
    setTimeout(() => setKbSaved(false), 3000);
  }

  const tabs: { id: Tab; label: string; desc: string }[] = [
    { id: "inbox", label: "Inbox", desc: "Missed call log" },
    { id: "consultant", label: "AI Consultant", desc: "Chat with your AI" },
    { id: "knowledge", label: "Knowledge Base", desc: "Train your AI" },
  ];

  return (
    <div className="min-h-screen bg-zinc-100 text-zinc-900 flex flex-col">
      <header className="bg-white border-b border-zinc-200 px-6 h-14 flex items-center justify-between shrink-0">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="w-6 h-6 bg-zinc-900 rounded-md flex items-center justify-center">
              <span className="text-white text-[10px] font-black">F</span>
            </div>
            <span className="font-bold tracking-tight text-zinc-900 text-sm">FUGTH MANAGEMENT</span>
          </div>
        </Link>
        <div className="flex items-center gap-3">
          <span className="text-zinc-400 text-xs uppercase tracking-wider hidden sm:block">Client Dashboard</span>
          <div className="w-7 h-7 rounded-full bg-zinc-200 border border-zinc-300 flex items-center justify-center text-xs font-bold text-zinc-600">C</div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        <aside className="w-56 border-r border-zinc-200 bg-white flex flex-col py-4 px-2 shrink-0 hidden md:flex">
          <p className="text-zinc-400 text-[10px] uppercase tracking-widest px-3 mb-3 font-semibold">Navigation</p>
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`w-full text-left px-3 py-2.5 rounded-md mb-1 transition-colors ${
                tab === t.id ? "bg-zinc-900 text-white" : "text-zinc-600 hover:bg-zinc-50 hover:text-zinc-900"
              }`}
            >
              <p className="text-sm font-medium">{t.label}</p>
              <p className={`text-xs mt-0.5 ${tab === t.id ? "text-zinc-400" : "text-zinc-400"}`}>{t.desc}</p>
            </button>
          ))}
          <div className="flex-1" />
          <div className="border-t border-zinc-200 pt-4 px-3 space-y-1">
            <p className="text-zinc-400 text-[10px] uppercase tracking-widest mb-2 font-semibold">Account</p>
            <button className="w-full text-left text-zinc-500 text-xs hover:text-zinc-900 py-1.5 transition-colors">Settings</button>
            <Link href="/"><button className="w-full text-left text-zinc-500 text-xs hover:text-zinc-900 py-1.5 transition-colors">Sign Out</button></Link>
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto">
          {/* INBOX */}
          {tab === "inbox" && (
            <div className="p-8">
              <div className="mb-8">
                <h1 className="text-xl font-black tracking-tight mb-1">Inbox</h1>
                <p className="text-zinc-500 text-sm">Your missed call log and AI recovery status.</p>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-8">
                {[{ label: "Missed This Week", value: "4" }, { label: "Recovered", value: "1" }, { label: "Recovery Rate", value: "25%" }].map((s) => (
                  <div key={s.label} className="bg-white border border-zinc-200 rounded-xl p-5">
                    <p className="text-zinc-400 text-xs uppercase tracking-wider mb-2 font-medium">{s.label}</p>
                    <p className="text-2xl font-black text-zinc-900">{s.value}</p>
                  </div>
                ))}
              </div>
              <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
                <div className="border-b border-zinc-200 px-5 py-3 flex items-center justify-between">
                  <p className="text-zinc-500 text-xs uppercase tracking-wider font-medium">Recent Calls</p>
                  <button className="text-xs text-zinc-400 hover:text-zinc-900 transition-colors">Export CSV</button>
                </div>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-zinc-100">
                      {["Caller", "Time", "Status", "Notes"].map((h) => (
                        <th key={h} className="text-left px-5 py-3 text-zinc-400 text-xs font-semibold uppercase tracking-wider">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {MOCK_CALLS.map((call, i) => (
                      <tr key={call.id} className={`hover:bg-zinc-50 transition-colors ${i < MOCK_CALLS.length - 1 ? "border-b border-zinc-100" : ""}`}>
                        <td className="px-5 py-3 text-zinc-900 font-mono text-sm">{call.caller}</td>
                        <td className="px-5 py-3 text-zinc-500 text-sm">{call.time}</td>
                        <td className="px-5 py-3">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${call.status === "Recovered" ? "bg-zinc-100 text-zinc-700 border border-zinc-200" : "bg-zinc-50 text-zinc-500 border border-zinc-200"}`}>
                            {call.status}
                          </span>
                        </td>
                        <td className="px-5 py-3 text-zinc-400 text-sm">{call.notes || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* AI CONSULTANT */}
          {tab === "consultant" && (
            <div className="flex flex-col" style={{ height: "calc(100vh - 56px)" }}>
              <div className="border-b border-zinc-200 bg-white px-8 py-5 shrink-0">
                <h1 className="text-xl font-black tracking-tight mb-0.5">AI Consultant</h1>
                <p className="text-zinc-500 text-sm">Ask anything about your business — trained on your data.</p>
              </div>
              <div className="flex-1 overflow-y-auto px-8 py-6 space-y-5 bg-zinc-50">
                {messages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                    {msg.role === "assistant" && (
                      <div className="w-7 h-7 rounded-full bg-zinc-900 flex items-center justify-center text-white text-[10px] font-bold mr-2.5 mt-0.5 shrink-0">AI</div>
                    )}
                    <div className={`max-w-lg px-4 py-3 rounded-xl text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-zinc-900 text-white rounded-br-sm"
                        : "bg-white border border-zinc-200 text-zinc-800 rounded-bl-sm shadow-sm"
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
                {sending && (
                  <div className="flex justify-start">
                    <div className="w-7 h-7 rounded-full bg-zinc-900 flex items-center justify-center text-white text-[10px] font-bold mr-2.5 shrink-0">AI</div>
                    <div className="bg-white border border-zinc-200 px-4 py-3 rounded-xl shadow-sm flex items-center gap-1">
                      {[0, 150, 300].map((d) => (
                        <span key={d} className="w-1.5 h-1.5 rounded-full bg-zinc-400 animate-bounce" style={{ animationDelay: `${d}ms` }} />
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <div className="border-t border-zinc-200 bg-white px-8 py-4 shrink-0">
                <form onSubmit={sendMessage} className="flex gap-3">
                  <input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask about your business — pricing, customers, strategy..."
                    className="flex-1 border border-zinc-200 bg-zinc-50 text-zinc-900 text-sm rounded-md px-4 py-2.5 placeholder-zinc-400 focus:outline-none focus:border-zinc-400 transition-colors"
                  />
                  <button disabled={!input.trim() || sending} className="px-5 py-2.5 bg-zinc-900 text-white text-sm font-semibold rounded-md hover:bg-zinc-700 transition-colors disabled:opacity-40">
                    Send
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* KNOWLEDGE BASE */}
          {tab === "knowledge" && (
            <div className="p-8 max-w-2xl">
              <div className="mb-8">
                <h1 className="text-xl font-black tracking-tight mb-1">Knowledge Base</h1>
                <p className="text-zinc-500 text-sm">The more you tell us, the smarter your AI gets.</p>
              </div>
              <form onSubmit={saveKb} className="space-y-5">
                <div className="bg-white border border-zinc-200 rounded-xl p-6 space-y-5">
                  {[
                    { key: "businessName", label: "Business Name", placeholder: "e.g. Valley Roofing Co." },
                    { key: "industry", label: "Industry", placeholder: "e.g. Roofing & Gutters" },
                    { key: "location", label: "Location", placeholder: "e.g. Burbank, CA" },
                    { key: "hours", label: "Operating Hours", placeholder: "e.g. Mon–Fri 8am–6pm, Sat 9am–2pm" },
                  ].map((f) => (
                    <div key={f.key} className="space-y-1.5">
                      <label className="text-zinc-600 text-xs font-semibold uppercase tracking-wider">{f.label}</label>
                      <input
                        type="text"
                        value={kbFields[f.key as keyof typeof kbFields]}
                        onChange={(e) => setKbFields((prev) => ({ ...prev, [f.key]: e.target.value }))}
                        placeholder={f.placeholder}
                        className="w-full border border-zinc-200 bg-zinc-50 text-zinc-900 text-sm rounded-md px-3 py-2.5 placeholder-zinc-400 focus:outline-none focus:border-zinc-400 transition-colors"
                      />
                    </div>
                  ))}
                  {[
                    { key: "services", label: "Services Offered", placeholder: "List your services, one per line...", rows: 3 },
                    { key: "notes", label: "Additional Notes", placeholder: "Pricing, FAQs, unique value props, anything your AI should know...", rows: 4 },
                  ].map((f) => (
                    <div key={f.key} className="space-y-1.5">
                      <label className="text-zinc-600 text-xs font-semibold uppercase tracking-wider">{f.label}</label>
                      <textarea
                        value={kbFields[f.key as keyof typeof kbFields]}
                        onChange={(e) => setKbFields((prev) => ({ ...prev, [f.key]: e.target.value }))}
                        placeholder={f.placeholder}
                        rows={f.rows}
                        className="w-full border border-zinc-200 bg-zinc-50 text-zinc-900 text-sm rounded-md px-3 py-2.5 placeholder-zinc-400 focus:outline-none focus:border-zinc-400 transition-colors resize-none"
                      />
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-3">
                  <button type="submit" className="px-6 py-2.5 bg-zinc-900 text-white text-sm font-semibold rounded-md hover:bg-zinc-700 transition-colors">
                    Save Knowledge Base
                  </button>
                  {kbSaved && <span className="text-zinc-500 text-sm">Saved.</span>}
                </div>
              </form>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
