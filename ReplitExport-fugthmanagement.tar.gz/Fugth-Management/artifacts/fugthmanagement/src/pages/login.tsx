import { useState } from "react";
import { Link, useLocation } from "wouter";

export default function Login() {
  const [, navigate] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigate("/dashboard");
    }, 1000);
  }

  return (
    <div className="min-h-screen bg-zinc-100 flex flex-col">
      <nav className="bg-white border-b border-zinc-200 px-6 h-16 flex items-center justify-between">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="w-7 h-7 bg-zinc-900 rounded-md flex items-center justify-center">
              <span className="text-white text-xs font-black">F</span>
            </div>
            <span className="font-bold tracking-tight text-zinc-900 text-sm">FUGTH MANAGEMENT</span>
          </div>
        </Link>
        <Link href="/">
          <button className="text-zinc-500 text-sm hover:text-zinc-900 transition-colors">← Back to site</button>
        </Link>
      </nav>

      <div className="flex-1 flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-sm">
          <div className="bg-white border border-zinc-200 rounded-2xl p-8 shadow-sm space-y-6">
            <div className="space-y-1">
              <h1 className="text-2xl font-black tracking-tight text-zinc-900">Client Login</h1>
              <p className="text-zinc-500 text-sm">Sign in to your management dashboard.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-zinc-700 text-xs font-semibold uppercase tracking-wider">Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full border border-zinc-200 bg-zinc-50 text-zinc-900 text-sm rounded-md px-3 py-2.5 placeholder-zinc-400 focus:outline-none focus:border-zinc-400 transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-zinc-700 text-xs font-semibold uppercase tracking-wider">Password</label>
                  <button type="button" className="text-zinc-400 text-xs hover:text-zinc-700 transition-colors">Forgot?</button>
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full border border-zinc-200 bg-zinc-50 text-zinc-900 text-sm rounded-md px-3 py-2.5 placeholder-zinc-400 focus:outline-none focus:border-zinc-400 transition-colors"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-zinc-900 text-white text-sm font-semibold rounded-md hover:bg-zinc-700 transition-colors disabled:opacity-50"
              >
                {loading ? "Signing in..." : "Sign In"}
              </button>
            </form>

            <p className="text-center text-zinc-400 text-xs">
              Not a client?{" "}
              <a href="/#pricing" className="text-zinc-700 font-medium hover:text-zinc-900 transition-colors">
                View plans
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
