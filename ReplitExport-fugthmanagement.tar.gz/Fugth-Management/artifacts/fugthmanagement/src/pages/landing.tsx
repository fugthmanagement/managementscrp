import { useState } from "react";
import { Link } from "wouter";

const NAV_TABS = [
  { id: "home", label: "Home", href: "/" },
  { id: "features", label: "Features", href: "#features" },
  { id: "services", label: "Services", href: "#services" },
  { id: "email-leads", label: "Email & Leads", href: "#email-leads" },
  { id: "pricing", label: "Pricing", href: "#pricing" },
];

export default function Landing() {
  const [activeTab, setActiveTab] = useState("home");
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  function handleWaitlist(e: React.FormEvent) {
    e.preventDefault();
    setSubmitted(true);
  }

  return (
    <div className="min-h-screen bg-zinc-100 text-zinc-900">

      {/* ─── NAV ─── */}
      <nav className="sticky top-0 z-50 bg-white border-b border-zinc-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="w-7 h-7 bg-zinc-900 rounded-md flex items-center justify-center">
              <span className="text-white text-xs font-black">F</span>
            </div>
            <span className="font-bold tracking-tight text-zinc-900 text-sm hidden sm:block">
              FUGTH MANAGEMENT
            </span>
          </div>

          {/* Tabs */}
          <div className="hidden md:flex items-center gap-1">
            {NAV_TABS.map((t) => (
              <a
                key={t.id}
                href={t.href}
                onClick={() => setActiveTab(t.id)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === t.id
                    ? "bg-zinc-900 text-white"
                    : "text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100"
                }`}
              >
                {t.label}
              </a>
            ))}
          </div>

          <Link href="/login">
            <button className="px-4 py-2 bg-zinc-900 text-white text-sm font-semibold rounded-md hover:bg-zinc-700 transition-colors">
              Client Login
            </button>
          </Link>
        </div>
      </nav>

      {/* ─── HERO ─── */}
      <section id="home" className="bg-white border-b border-zinc-200">
        <div className="max-w-7xl mx-auto px-6 py-24 md:py-32 grid md:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-zinc-100 border border-zinc-200 rounded-full text-zinc-600 text-xs font-medium tracking-wide">
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-900" />
              AI That Sounds Like a Human
            </div>

            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-black tracking-tight leading-tight text-zinc-900">
                Your Business,
                <br />
                <span className="text-zinc-400">Always</span>
                <br />
                Answering.
              </h1>
              <p className="text-zinc-500 text-lg leading-relaxed max-w-md">
                Fugth Management's AI handles your calls, emails, and leads —
                responding like your most trusted employee, 24 hours a day.
                Never miss a customer again.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <Link href="/login">
                <button className="px-7 py-3 bg-zinc-900 text-white text-sm font-semibold rounded-md hover:bg-zinc-700 transition-colors">
                  Get Started Free
                </button>
              </Link>
              <a href="#features">
                <button className="px-7 py-3 border border-zinc-300 text-zinc-700 text-sm font-medium rounded-md hover:bg-zinc-50 transition-colors">
                  See How It Works
                </button>
              </a>
            </div>

            <p className="text-zinc-400 text-xs">No credit card required · 14-day free trial</p>
          </div>

          {/* Hero card mock */}
          <div className="hidden md:block">
            <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-6 space-y-4 shadow-sm">
              <div className="flex items-center gap-3 border-b border-zinc-200 pb-4">
                <div className="w-9 h-9 rounded-full bg-zinc-900 flex items-center justify-center text-white text-xs font-bold">AI</div>
                <div>
                  <p className="text-sm font-semibold text-zinc-900">Fugth AI Assistant</p>
                  <p className="text-xs text-zinc-400">Responding now · Online</p>
                </div>
                <div className="ml-auto w-2 h-2 rounded-full bg-green-500" />
              </div>
              {[
                { from: "caller", text: "Hi, are you guys open on Saturdays? I need an estimate." },
                { from: "ai", text: "Absolutely! We're open Saturday 9am–3pm. I'd love to get you scheduled — what service do you need an estimate for?" },
                { from: "caller", text: "Roof repair, maybe 1,500 sq ft." },
                { from: "ai", text: "Perfect. I can book you for a free on-site estimate this Saturday at 10am. Can I get your name and best callback number?" },
              ].map((msg, i) => (
                <div key={i} className={`flex ${msg.from === "caller" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[80%] px-3.5 py-2.5 rounded-xl text-sm leading-relaxed ${
                    msg.from === "caller"
                      ? "bg-zinc-200 text-zinc-800 rounded-br-sm"
                      : "bg-zinc-900 text-white rounded-bl-sm"
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              <p className="text-center text-[10px] text-zinc-400 pt-2">
                AI-powered · Sounds human · Books appointments
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ─── SOCIAL PROOF STRIP ─── */}
      <div className="bg-zinc-900 py-4">
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap items-center justify-center gap-8">
          {["Revenue Recovery", "Lead Generation", "Email Automation", "Reputation Defense", "24/7 AI Answering"].map((item) => (
            <span key={item} className="text-zinc-400 text-xs uppercase tracking-widest font-medium">
              {item}
            </span>
          ))}
        </div>
      </div>

      {/* ─── FEATURES ─── */}
      <section id="features" className="py-24 px-6 bg-white border-b border-zinc-200">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 space-y-3">
            <p className="text-zinc-400 text-xs uppercase tracking-widest font-medium">Platform Features</p>
            <h2 className="text-4xl font-black tracking-tight text-zinc-900">Built to run your business<br />while you focus on it.</h2>
            <p className="text-zinc-500 max-w-xl mx-auto text-base">
              One platform. Every customer touchpoint — calls, emails, reviews, leads — handled automatically by AI that sounds exactly like you.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: "🎙️",
                title: "AI Call Answering",
                desc: "Our AI picks up every call, answers questions, books appointments, and captures lead info — in a natural, conversational tone customers can't distinguish from a real person.",
                badge: "Most Popular",
              },
              {
                icon: "✉️",
                title: "Smart Email Automation",
                desc: "Follow-up emails, appointment reminders, review requests, and re-engagement campaigns — all written in your voice and sent at exactly the right moment.",
                badge: null,
              },
              {
                icon: "📍",
                title: "Lead Generation",
                desc: "We find businesses and homeowners in your area actively looking for your services and deliver them straight to your inbox, pre-qualified and ready to convert.",
                badge: "New",
              },
              {
                icon: "⭐",
                title: "Reputation Defense",
                desc: "Monitor every review across Google, Yelp, and Facebook. AI-drafted responses go out within minutes — turning negative reviews into reputation wins.",
                badge: null,
              },
              {
                icon: "🤖",
                title: "Executive AI Consultant",
                desc: "Ask your AI anything about your business. Trained on your own data, it surfaces insights on pricing, operations, and customer trends on demand.",
                badge: null,
              },
              {
                icon: "📊",
                title: "Unified Dashboard",
                desc: "Every call, email, lead, and review in one clean interface. Know exactly what's happening in your business at any moment.",
                badge: null,
              },
            ].map((f) => (
              <div key={f.title} className="bg-zinc-50 border border-zinc-200 rounded-xl p-6 hover:shadow-md hover:border-zinc-300 transition-all group">
                <div className="flex items-start justify-between mb-4">
                  <span className="text-2xl">{f.icon}</span>
                  {f.badge && (
                    <span className="px-2 py-0.5 bg-zinc-900 text-white text-[10px] font-semibold rounded-full uppercase tracking-wide">
                      {f.badge}
                    </span>
                  )}
                </div>
                <h3 className="font-bold text-zinc-900 mb-2 group-hover:text-zinc-700 transition-colors">{f.title}</h3>
                <p className="text-zinc-500 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── SERVICES ─── */}
      <section id="services" className="py-24 px-6 bg-zinc-50 border-b border-zinc-200">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16 space-y-3">
            <p className="text-zinc-400 text-xs uppercase tracking-widest font-medium">Core Services</p>
            <h2 className="text-4xl font-black tracking-tight text-zinc-900">Three engines.<br />One system.</h2>
          </div>

          <div className="space-y-4">
            {[
              {
                num: "01",
                title: "Revenue Recovery",
                subtitle: "AI Call Handling",
                desc: "Every missed call is a missed paycheck. Our AI answers instantly, qualifies the caller, books the appointment, and sends a follow-up — so you recover revenue even while you sleep.",
                details: ["24/7 call answering", "Appointment booking", "Lead qualification", "SMS & voicemail follow-up"],
              },
              {
                num: "02",
                title: "Digital Reputation Defender",
                subtitle: "Review & Rating Management",
                desc: "Your online reputation is your most valuable asset. We monitor every platform, respond to reviews in your voice within minutes, and run proactive campaigns to collect 5-star reviews from happy customers.",
                details: ["Google, Yelp & Facebook monitoring", "AI-drafted responses", "Review request campaigns", "Sentiment analysis"],
              },
              {
                num: "03",
                title: "Executive AI Consultant",
                subtitle: "RAG-Powered Business Intelligence",
                desc: "An AI advisor that knows your business inside out. Upload your documents, FAQs, pricing, and history — then ask it anything. It answers like a seasoned business consultant, not a chatbot.",
                details: ["Custom knowledge base", "Natural language answers", "Pricing & ops insights", "Customer trend reports"],
              },
            ].map((s) => (
              <div key={s.num} className="bg-white border border-zinc-200 rounded-xl p-8 hover:shadow-md transition-all">
                <div className="grid md:grid-cols-3 gap-8 items-start">
                  <div className="md:col-span-2 space-y-3">
                    <div className="flex items-center gap-3">
                      <span className="text-zinc-300 font-mono text-sm">{s.num}</span>
                      <span className="w-8 h-px bg-zinc-200" />
                      <span className="text-zinc-400 text-xs uppercase tracking-wider">{s.subtitle}</span>
                    </div>
                    <h3 className="text-2xl font-black text-zinc-900">{s.title}</h3>
                    <p className="text-zinc-500 leading-relaxed">{s.desc}</p>
                  </div>
                  <div className="space-y-2">
                    {s.details.map((d) => (
                      <div key={d} className="flex items-center gap-2 text-sm text-zinc-600">
                        <div className="w-4 h-4 rounded-full bg-zinc-100 border border-zinc-200 flex items-center justify-center shrink-0">
                          <span className="text-zinc-900 text-[9px] font-black">✓</span>
                        </div>
                        {d}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── EMAIL & LEADS ─── */}
      <section id="email-leads" className="py-24 px-6 bg-white border-b border-zinc-200">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="space-y-6">
              <div>
                <p className="text-zinc-400 text-xs uppercase tracking-widest font-medium mb-3">Email & Lead Generation</p>
                <h2 className="text-4xl font-black tracking-tight text-zinc-900 leading-tight">
                  Stop waiting for
                  <br />customers to find you.
                </h2>
              </div>
              <p className="text-zinc-500 leading-relaxed">
                We combine automated email campaigns with targeted local lead generation so your pipeline never runs dry. Our AI writes the emails, finds the leads, and tracks what converts.
              </p>
              <div className="space-y-4">
                {[
                  { icon: "📧", title: "Email Campaigns", desc: "AI-written sequences in your brand voice — onboarding, re-engagement, seasonal offers." },
                  { icon: "🗺️", title: "Local Lead Scraping", desc: "We find businesses and homeowners in any zip code who need your services right now." },
                  { icon: "🔁", title: "Automated Follow-Up", desc: "Every lead gets a personalized follow-up sequence until they convert or opt out." },
                ].map((item) => (
                  <div key={item.title} className="flex gap-4 p-4 bg-zinc-50 border border-zinc-200 rounded-lg">
                    <span className="text-xl shrink-0">{item.icon}</span>
                    <div>
                      <p className="font-semibold text-zinc-900 text-sm mb-0.5">{item.title}</p>
                      <p className="text-zinc-500 text-sm">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Email preview mock */}
            <div className="space-y-3">
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-zinc-900 px-4 py-3 flex items-center gap-2">
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-zinc-600" />
                    <div className="w-2.5 h-2.5 rounded-full bg-zinc-600" />
                    <div className="w-2.5 h-2.5 rounded-full bg-zinc-600" />
                  </div>
                  <span className="text-zinc-400 text-xs ml-2">AI-Generated Email Preview</span>
                </div>
                <div className="p-5 space-y-3">
                  <div className="space-y-1">
                    <p className="text-zinc-400 text-xs">Subject</p>
                    <p className="text-zinc-900 font-semibold text-sm">Hey [First Name] — still thinking about that roof?</p>
                  </div>
                  <div className="border-t border-zinc-200 pt-3">
                    <p className="text-zinc-600 text-sm leading-relaxed">
                      Hi Maria,<br /><br />
                      I wanted to follow up on your inquiry from last week. We had a couple cancellations and have an opening this Thursday at 2pm — would that work for a free estimate?<br /><br />
                      No pressure at all. Just wanted to make sure you got taken care of before the rain season hits.<br /><br />
                      — Mike at Valley Roofing
                    </p>
                  </div>
                  <div className="pt-1">
                    <span className="inline-block px-3 py-1.5 bg-zinc-900 text-white text-xs font-medium rounded">
                      Book My Free Estimate →
                    </span>
                  </div>
                </div>
              </div>
              <p className="text-center text-xs text-zinc-400">Written by AI · Sounds like you · Sent automatically</p>
            </div>
          </div>
        </div>
      </section>

      {/* ─── AI HOOK SECTION ─── */}
      <section className="py-24 px-6 bg-zinc-900">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <p className="text-zinc-500 text-xs uppercase tracking-widest font-medium">The Core Difference</p>
          <h2 className="text-4xl md:text-5xl font-black tracking-tight text-white leading-tight">
            Our AI doesn't sound like a bot.
            <br />
            <span className="text-zinc-400">It sounds like your best employee.</span>
          </h2>
          <p className="text-zinc-400 text-lg max-w-2xl mx-auto leading-relaxed">
            Anyone can script a chatbot. We built something different — an AI trained on how real local business owners talk to customers. It's warm, it's direct, and it gets things done. Customers don't know it's AI. They just know they got helped.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
            {[
              { stat: "< 2s", label: "Average response time" },
              { stat: "94%", label: "Caller satisfaction rate" },
              { stat: "3×", label: "More leads captured vs voicemail" },
            ].map((s) => (
              <div key={s.label} className="bg-zinc-800 border border-zinc-700 rounded-xl p-6">
                <p className="text-4xl font-black text-white mb-2">{s.stat}</p>
                <p className="text-zinc-400 text-sm">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── PRICING ─── */}
      <section id="pricing" className="py-24 px-6 bg-white border-b border-zinc-200">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-3">
            <p className="text-zinc-400 text-xs uppercase tracking-widest font-medium">Pricing</p>
            <h2 className="text-4xl font-black tracking-tight text-zinc-900">Simple. No surprises.</h2>
            <p className="text-zinc-500">Cancel anytime. No contracts.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: "Starter",
                price: "$49",
                per: "/mo",
                desc: "Perfect for getting started",
                features: ["AI call answering (500 calls/mo)", "Email follow-up sequences", "Google review monitoring", "Lead inbox (25 leads/mo)", "Basic dashboard"],
                cta: "Start Free Trial",
                highlight: false,
              },
              {
                name: "Growth",
                price: "$129",
                per: "/mo",
                desc: "Most popular for growing businesses",
                features: ["Unlimited AI call answering", "Full email automation suite", "Reputation management", "Lead generation (150/mo)", "AI Consultant chat", "Priority support"],
                cta: "Start Free Trial",
                highlight: true,
              },
              {
                name: "Enterprise",
                price: "$299",
                per: "/mo",
                desc: "Built for multi-location operations",
                features: ["Everything in Growth", "Unlimited locations", "Custom AI training", "Dedicated account manager", "API access", "SLA guarantee"],
                cta: "Talk to Sales",
                highlight: false,
              },
            ].map((p) => (
              <div
                key={p.name}
                className={`relative rounded-xl p-7 border transition-all ${
                  p.highlight
                    ? "bg-zinc-900 border-zinc-700 shadow-xl"
                    : "bg-zinc-50 border-zinc-200 hover:shadow-md"
                }`}
              >
                {p.highlight && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-white text-zinc-900 text-[10px] font-black rounded-full uppercase tracking-wider border border-zinc-200">
                    Most Popular
                  </div>
                )}
                <div className="mb-5">
                  <p className={`text-xs font-semibold uppercase tracking-wider mb-1 ${p.highlight ? "text-zinc-400" : "text-zinc-500"}`}>{p.name}</p>
                  <div className="flex items-baseline gap-1">
                    <span className={`text-5xl font-black ${p.highlight ? "text-white" : "text-zinc-900"}`}>{p.price}</span>
                    <span className={`text-sm ${p.highlight ? "text-zinc-500" : "text-zinc-400"}`}>{p.per}</span>
                  </div>
                  <p className={`text-xs mt-1 ${p.highlight ? "text-zinc-500" : "text-zinc-400"}`}>{p.desc}</p>
                </div>

                <ul className="space-y-2.5 mb-7">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm">
                      <span className={`mt-0.5 shrink-0 ${p.highlight ? "text-zinc-400" : "text-zinc-500"}`}>✓</span>
                      <span className={p.highlight ? "text-zinc-300" : "text-zinc-600"}>{f}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-3 rounded-md text-sm font-semibold transition-colors ${
                  p.highlight
                    ? "bg-white text-zinc-900 hover:bg-zinc-100"
                    : "bg-zinc-900 text-white hover:bg-zinc-700"
                }`}>
                  {p.cta}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── WAITLIST CTA ─── */}
      <section className="py-24 px-6 bg-zinc-100">
        <div className="max-w-2xl mx-auto text-center space-y-6">
          <h2 className="text-4xl font-black tracking-tight text-zinc-900">Ready to stop missing customers?</h2>
          <p className="text-zinc-500 leading-relaxed">
            Join local businesses already using Fugth Management to recover revenue, get more leads, and let AI handle the work.
          </p>
          {!submitted ? (
            <form onSubmit={handleWaitlist} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="flex-1 px-4 py-3 border border-zinc-300 rounded-md text-sm bg-white focus:outline-none focus:border-zinc-500 transition-colors"
              />
              <button type="submit" className="px-6 py-3 bg-zinc-900 text-white text-sm font-semibold rounded-md hover:bg-zinc-700 transition-colors shrink-0">
                Get Early Access
              </button>
            </form>
          ) : (
            <div className="py-4 px-6 bg-white border border-zinc-200 rounded-xl text-zinc-700 text-sm font-medium">
              You're on the list. We'll be in touch shortly.
            </div>
          )}
        </div>
      </section>

      {/* ─── FOOTER ─── */}
      <footer className="bg-zinc-900 border-t border-zinc-800 py-10 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 bg-white rounded-sm flex items-center justify-center">
                <span className="text-zinc-900 text-[10px] font-black">F</span>
              </div>
              <span className="text-white font-bold text-sm">FUGTH MANAGEMENT</span>
            </div>
            <p className="text-zinc-500 text-xs leading-relaxed">Operational intelligence for local business.</p>
          </div>
          {[
            { heading: "Product", links: ["Features", "Pricing", "Email & Leads", "AI Consultant"] },
            { heading: "Company", links: ["About", "Contact", "Blog", "Careers"] },
            { heading: "Legal", links: ["Privacy Policy", "Terms of Service", "Cookie Policy"] },
          ].map((col) => (
            <div key={col.heading}>
              <p className="text-zinc-400 text-xs font-semibold uppercase tracking-wider mb-3">{col.heading}</p>
              <ul className="space-y-2">
                {col.links.map((l) => (
                  <li key={l}>
                    <a href="#" className="text-zinc-600 text-sm hover:text-white transition-colors">{l}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-zinc-800 pt-6 flex items-center justify-between">
          <p className="text-zinc-700 text-xs">&copy; {new Date().getFullYear()} Fugth Management. All rights reserved.</p>
          <Link href="/dev-admin">
            <span className="text-zinc-800 text-[10px] hover:text-zinc-600 transition-colors cursor-pointer select-none">·</span>
          </Link>
        </div>
      </footer>
    </div>
  );
}
